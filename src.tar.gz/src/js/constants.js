export const MOBILE_SLIDER_BREAKPOINT = "(max-width: 768px)";
