
/*!*
 * ВНИМАНИЕ! Этот файл генерируется автоматически.
 * Любые изменения этого файла будут потеряны при следующей компиляции.
 * Любое изменение проекта без возможности компиляции ДОЛЬШЕ И ДОРОЖЕ в 2-5 раз.
 */

/* global require */

require('../blocks/accordeon/accordeon.js');
require('../blocks/counter/counter.js');
require('../blocks/field/field.js');
require('../blocks/header/header.js');
require('../blocks/hero/hero.js');
require('../blocks/mobile-slider/mobile-slider.js');
require('../blocks/product/product.js');
require('../blocks/product-small/product-small.js');
require('../blocks/product-xxl/product-xxl.js');
require('../blocks/search-form/search-form.js');
require('../blocks/subscription/subscription.js');
require('../blocks/tabs/tabs.js');
require('../blocks/video/video.js');
require('./script.js');

/*!*
 * ВНИМАНИЕ! Этот файл генерируется автоматически.
 * Любые изменения этого файла будут потеряны при следующей компиляции.
 * Любое изменение проекта без возможности компиляции ДОЛЬШЕ И ДОРОЖЕ в 2-5 раз.
 */

