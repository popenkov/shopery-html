export const toggleBodyLock = () => {
  document.body.classList.toggle("lock");
};
