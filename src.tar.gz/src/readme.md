These are the project source files from which the build is made.
Edit - these sources.
